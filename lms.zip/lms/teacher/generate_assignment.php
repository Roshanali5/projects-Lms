<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'C:\xampp\htdocs\lms\vendor\autoload.php';
use GuzzleHttp\Client;

$teacher_id = 0; // Update this after login
$connection = new mysqli('localhost', 'root', '', 'lms_db');
if ($connection->connect_error) {
    die("❌ Database connection failed: " . $connection->connect_error);
}

$client = new Client();
$apiKey = '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';
$apiUrl = 'https://openrouter.ai/api/v1/chat/completions';

$assignmentCreated = false;
$errorMessage = '';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['course_id'])) {
    $course_id = $_POST['course_id'];

    $courseQuery = "SELECT course_name, level FROM `add-courses` WHERE id = '$course_id'";
    $courseResult = $connection->query($courseQuery);

    if ($courseResult && $courseResult->num_rows > 0) {
        $course = $courseResult->fetch_assoc();
        $course_name = $course['course_name'];
        $level = $course['level'];

        $title = "Generated Assignment";
        $deadline = date('Y-m-d', strtotime('+7 days'));
        $total_marks = 150;

        $insertAssignment = "INSERT INTO assignments (course_id, title, deadline, total_marks, created_at, updated_at)
                            VALUES ('$course_id', '$title', '$deadline', '$total_marks', NOW(), NOW())";

        if ($connection->query($insertAssignment)) {
            $assignment_id = $connection->insert_id;

            try {
                $prompt = "Generate 3 long, descriptive, subjective questions for the course '{$course_name}' for '{$level}' students. Each question should be detailed enough to be worth 50 marks.";

                $response = $client->post($apiUrl, [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $apiKey,
                        'Content-Type'  => 'application/json',
                        'HTTP-Referer'  => 'https://your-website.com',
                        'X-Title'       => 'Assignment Generator',
                    ],
                    'json' => [
                        'model' => 'openai/gpt-3.5-turbo',
                        'messages' => [
                            ['role' => 'user', 'content' => $prompt],
                        ],
                        'max_tokens' => 800,
                        'temperature' => 0.7,
                    ],
                ]);

                $body = json_decode($response->getBody(), true);
                $questions = preg_split("/\n+/", trim($body['choices'][0]['message']['content']));

                foreach ($questions as $q) {
                    $q = trim($q);
                    if ($q !== '') {
                        $insertQ = "INSERT INTO assignment_questions (assignment_id, question_text, marks, created_at)
                                    VALUES ('$assignment_id', '$q', 50, NOW())";
                        $connection->query($insertQ);
                    }
                }

                $assignmentCreated = true;

            } catch (Exception $e) {
                $errorMessage = "❌ AI Error: " . $e->getMessage();
            }
        } else {
            $errorMessage = "❌ Assignment insert failed: " . $connection->error;
        }
    } else {
        $errorMessage = "❌ Course not found.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Assignment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f7f9fc;
        }
        h3 {
            color: #333;
        }
        select, button {
            padding: 10px;
            font-size: 16px;
            margin-top: 5px;
            margin-bottom: 15px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .message-box {
            background: #e9f9ed;
            padding: 15px;
            border: 1px solid #c7e8ce;
            border-left: 5px solid #4CAF50;
            border-radius: 5px;
            margin-top: 20px;
            color: #2f6627;
        }
        .error-box {
            background: #ffe9e9;
            padding: 15px;
            border: 1px solid #f3bcbc;
            border-left: 5px solid #d30000;
            border-radius: 5px;
            margin-top: 20px;
            color: #9b1c1c;
        }
    </style>
</head>
<body>

<h3>📘 Select Course to Generate Assignment</h3>

<form method="POST">
    <select name="course_id" required>
        <option value="">-- Select Course --</option>
        <?php
        $sql = "SELECT DISTINCT ce.course_id, ac.course_name, ac.level 
                FROM course_enrollments ce
                JOIN `add-courses` ac ON ce.course_id = ac.id
                WHERE ac.teacher_id = $teacher_id";

        $result = $connection->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $cid = $row['course_id'];
                $name = $row['course_name'];
                $level = $row['level'];
                echo "<option value='$cid'>{$name} ({$level})</option>";
            }
        } else {
            echo "<option disabled>No enrolled courses found.</option>";
        }
        ?>
    </select><br>
    <button type="submit">🧠 Generate Assignment</button>
</form>

<?php if ($assignmentCreated): ?>
    <div class="message-box">
        ✅ Assignment and questions have been generated automatically and stored in the database.
    </div>
<?php endif; ?>

<?php if (!empty($errorMessage)): ?>
    <div class="error-box">
        <?= htmlspecialchars($errorMessage) ?>
    </div>
<?php endif; ?>

</body>
</html>
