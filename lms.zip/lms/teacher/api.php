<?php
if (isset($_GET['course_id_level'])) {
    list($course_id, $level) = explode('|', $_GET['course_id_level']);

    echo "Selected Course ID: " . $course_id . "<br>";
    echo "Selected Level: " . $level . "<br>";

    // OpenAI API integration to generate assignment
    $api_key = 'YOUR_OPENAI_API_KEY';
    $url = 'https://api.openai.com/v1/completions';
    
    // Prepare prompt based on course and level
    $prompt = "Generate an assignment for a {$level} level course in {$course_name}. Include programming questions.";

    $data = [
        'model' => 'text-davinci-003',  // You can change model as per your needs
        'prompt' => $prompt,
        'max_tokens' => 150,
        'temperature' => 0.7
    ];

    // Initialize cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $api_key
    ]);

    // Execute API call and get the result
    $response = curl_exec($ch);
    if(curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);

    // Decode the response and display the assignment
    $result = json_decode($response, true);
    if (isset($result['choices'][0]['text'])) {
        echo "Generated Assignment:<br>";
        echo nl2br($result['choices'][0]['text']);
    } else {
        echo "Error in generating assignment.";
    }
}
?>
