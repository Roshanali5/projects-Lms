<?php
session_start();
$teacher_id = $_SESSION['teacher_id'] ?? 0; // Update after login
$connection = new mysqli('localhost', 'root', '', 'lms_db');

if (isset($_GET['delete'])) {
    $assignment_id = intval($_GET['delete']);
    $connection->query("DELETE FROM assignment_questions WHERE assignment_id = $assignment_id");
    $connection->query("DELETE FROM assignments WHERE id = $assignment_id");
    header("Location: view_assignments.php?deleted=1");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Assignments</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f0f2f5; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 12px; border: 1px solid #ccc; text-align: left; }
        th { background: #f5f5f5; }
        .btn { padding: 5px 10px; border: none; cursor: pointer; text-decoration: none; }
        .view { background: #2196F3; color: white; }
        .delete { background: #f44336; color: white; }
        .download { background: #4CAF50; color: white; }
        .message { margin-bottom: 20px; padding: 10px; background: #d4edda; color: #155724; }
    </style>
</head>
<body>

<h2>📋 All Generated Assignments</h2>

<?php if (isset($_GET['deleted'])): ?>
    <div class="message">✅ Assignment deleted successfully.</div>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>Course Name</th>
            <th>Level</th>
            <th>Title</th>
            <th>Total Marks</th>
            <th>Submission</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT 
                    a.id, a.title, a.total_marks, a.deadline, 
                    ac.course_name, ac.level,
                    (SELECT submission_file FROM submissions WHERE assignment_id = a.id LIMIT 1) AS submission_file
                FROM assignments a
                JOIN `add-courses` ac ON a.course_id = ac.id
                WHERE ac.teacher_id = $teacher_id
                ORDER BY a.id DESC";

        $result = $connection->query($sql);
        if ($result && $result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
            <tr>
                <td><?= $row['course_name'] ?></td>
                <td><?= $row['level'] ?></td>
                <td><?= $row['title'] ?></td>
                <td><?= $row['total_marks'] ?></td>
                <td>
                    <?php if (!empty($row['submission_file'])): ?>
                        <a href="/lms/student/<?= htmlspecialchars($row['submission_file']) ?>" target="_blank" class="btn download">📥 View File</a>
                    <?php else: ?>
                        Not Submitted
                    <?php endif; ?>
                </td>
                <td>
                    <a href="view_questions.php?id=<?= $row['id'] ?>" class="btn view">View</a>
                    <a href="view_assignments.php?delete=<?= $row['id'] ?>" class="btn delete" onclick="return confirm('Delete this assignment?')">Delete</a>
                </td>
            </tr>
        <?php endwhile;
        else: ?>
            <tr><td colspan="6">No assignments found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
