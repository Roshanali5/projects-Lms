<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "lms_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$success_message = "";

// Fetch course details for editing
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM `add-courses` WHERE id = $id");

    if ($result->num_rows == 1) {
        $course = $result->fetch_assoc();
    } else {
        echo "Course not found!";
        exit();
    }
} else {
    echo "Invalid request!";
    exit();
}

// Update course
if (isset($_POST['update_course'])) {
    $new_name = $conn->real_escape_string($_POST['course_name']);
    $new_level = $conn->real_escape_string($_POST['level']);

    if (!empty($new_name) && !empty($new_level)) {
        $update = $conn->query("UPDATE `add-courses` SET course_name = '$new_name', level = '$new_level' WHERE id = $id");
        if ($update) {
            $success_message = "Course updated successfully!";
            // Refresh page to show updated values
            $course['course_name'] = $new_name;
            $course['level'] = $new_level;
        } else {
            $success_message = "Failed to update course.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Course</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            max-width: 600px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background: #3498db;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #2980b9;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Course</h2>

    <?php if (!empty($success_message)): ?>
        <div class="success"><?= $success_message ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="course_name" value="<?= htmlspecialchars($course['course_name']) ?>" required>
        <input type="text" name="level" value="<?= htmlspecialchars($course['level']) ?>" required>
        <button type="submit" name="update_course">Update Course</button>
    </form>
</div>

</body>
</html>
