<?php
session_start();
$connection = new mysqli("localhost", "root", "", "lms_db");

$teacher_id = $_SESSION['teacher_id'] ?? 1; // assuming teacher ID is stored in session

$sql = "SELECT * FROM notifications WHERE user_id = $teacher_id AND is_read = FALSE ORDER BY created_at DESC";
$result = $connection->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>📩 Notifications</title>
</head>
<body>

<h2>📩 Teacher Notifications</h2>

<?php if ($result && $result->num_rows > 0): ?>
    <ul>
        <?php while ($row = $result->fetch_assoc()): ?>
            <li>
                <?= htmlspecialchars($row['message']) ?>
                <br><small><?= htmlspecialchars($row['created_at']) ?></small>
            </li>
        <?php endwhile; ?>
    </ul>
<?php else: ?>
    <p>No new notifications.</p>
<?php endif; ?>

</body>
</html>
