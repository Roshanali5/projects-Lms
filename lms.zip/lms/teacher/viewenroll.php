<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "lms_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch course enrollments with student and course details (showing course name)
$query = "
    SELECT 
        course_enrollments.student_id, 
        `add-courses`.course_name,  -- Now showing course name
        course_enrollments.level
    FROM 
        course_enrollments
    INNER JOIN `add-courses` ON course_enrollments.course_id = `add-courses`.id
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Course Enrollment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            max-width: 900px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #3498db;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Student Course Enrollment</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Course Name</th>
                    <th>Level</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['student_id']) ?></td>
                        <td><?= htmlspecialchars($row['course_name']) ?></td> <!-- Displaying Course Name -->
                        <td><?= htmlspecialchars($row['level']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No students have enrolled in any courses yet.</p>
    <?php endif; ?>

</div>

</body>
</html>
