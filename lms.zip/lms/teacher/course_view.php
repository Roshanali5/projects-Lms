<?php
// Connect to database
$conn = new mysqli("localhost", "root", "", "lms_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Success message ke liye
$success_message = "";

// Add course jab form submit ho
if (isset($_POST['add_course'])) {
    $course_name = $conn->real_escape_string($_POST['course_name']);
    $level = $conn->real_escape_string($_POST['level']);

    if (!empty($course_name) && !empty($level)) {
        $query = "INSERT INTO `add-courses` (course_name, level) VALUES ('$course_name', '$level')";
        if ($conn->query($query)) {
            $success_message = "Course added successfully!";
        } else {
            $success_message = "Failed to add course.";
        }
    }
}

// Delete course jab form submit ho
if (isset($_POST['delete_id'])) {
    $delete_id = intval($_POST['delete_id']);
    $delete_query = "DELETE FROM `add-courses` WHERE id = $delete_id";
    if ($conn->query($delete_query)) {
        $success_message = "Course deleted successfully!";
    } else {
        $success_message = "Failed to delete course.";
    }
}

// Fetch all courses
$courses = $conn->query("SELECT * FROM `add-courses`");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Course</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            max-width: 800px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        input[type="text"], select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background: #4CAF50;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #45a049;
        }
        .btn-delete {
            background: #e74c3c;
        }
        .btn-delete:hover {
            background: #c0392b;
        }
        .btn-edit {
            background: #3498db;
        }
        .btn-edit:hover {
            background: #2980b9;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #f9f9f9;
        }
        .actions {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add a New Course</h2>

    <?php if (!empty($success_message)): ?>
        <div class="success"><?= $success_message ?></div>
    <?php endif; ?>

    <form action="" method="POST">
        <input type="text" name="course_name" placeholder="Course Name" required>
        <select name="level" required>
            <option value="">Select Student Level</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
        </select>
        <button type="submit" name="add_course">Add Course</button>
    </form>

    <h2>All Courses</h2>
    <table>
        <thead>
            <tr>
                <th>Course Name</th>
                <th>Student Level</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $courses->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['course_name']) ?></td>
                    <td><?= htmlspecialchars($row['level']) ?></td>
                    <td class="actions">
                        <form action="\lms\teacher\edit_course.php" method="GET" style="display:inline;">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <button class="btn-edit" type="submit">Edit</button>
                        </form>
                        <form action="" method="POST" style="display:inline;">
                            <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                            <button class="btn-delete" type="submit" onclick="return confirm('Are you sure to delete this course?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
