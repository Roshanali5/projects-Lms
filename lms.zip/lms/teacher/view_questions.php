<?php
$connection = new mysqli('localhost', 'root', '', 'lms_db');

if (!isset($_GET['id'])) {
    die("Assignment ID missing.");
}

$assignment_id = intval($_GET['id']);

// Get assignment info
$assignment = $connection->query("SELECT * FROM assignments WHERE id = $assignment_id")->fetch_assoc();
$course = $connection->query("SELECT * FROM `add-courses` WHERE id = {$assignment['course_id']}")->fetch_assoc();

// Get questions
$questions = $connection->query("SELECT * FROM assignment_questions WHERE assignment_id = $assignment_id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Assignment Questions</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f8f9fa; }
        h2 { margin-bottom: 5px; }
        .question { background: #fff; padding: 15px; border: 1px solid #ddd; margin-bottom: 10px; border-radius: 5px; }
        .back-btn { display: inline-block; margin-bottom: 20px; background: #6c757d; color: white; padding: 8px 12px; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>

<a href="C:\xampp\htdocs\lms\teacher\view_assignments.php" class="back-btn">⬅ Back to Assignments</a>

<h2>📘 <?= $course['course_name'] ?> (<?= $course['level'] ?>)</h2>
<p><strong>Assignment:</strong> <?= $assignment['title'] ?> | <strong>Total Marks:</strong> <?= $assignment['total_marks'] ?></p>
<hr>

<?php if ($questions->num_rows > 0): ?>
    <?php $i = 1; while ($q = $questions->fetch_assoc()): ?>
        <div class="question">
            <strong>Q<?= $i++ ?>:</strong> <?= htmlspecialchars($q['question_text']) ?>
            <div style="margin-top:5px;"><em>Marks: <?= $q['marks'] ?></em></div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>No questions found.</p>
<?php endif; ?>

</body>
</html>
