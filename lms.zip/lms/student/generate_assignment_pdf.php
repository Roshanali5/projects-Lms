<?php
require __DIR__ . '/../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Initialize Dompdf
$options = new Options();
$options->set('defaultFont', 'Arial');  // Ensure this line is correct

$dompdf = new Dompdf($options);

// Load HTML content
$html = '<h1>Generated Assignment PDF</h1>';
$html .= '<p>This is an example assignment</p>';

$dompdf->loadHtml($html);

// (Optional) Set paper size
$dompdf->setPaper('A4', 'portrait');

// Render PDF (first pass)
$dompdf->render();

// Output the generated PDF (force download)
$dompdf->stream("assignment.pdf", array("Attachment" => 1));
?>
