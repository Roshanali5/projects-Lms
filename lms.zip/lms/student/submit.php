<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
$connection = new mysqli("localhost", "root", "", "lms_db");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$student_id = $_SESSION['student_id'] ?? 2;  // Default to 2 for testing
$assignment_id = $_GET['id'] ?? null;

if ($assignment_id === null) {
    die("Error: Assignment ID is missing.");
}

$score_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['assignment_file'])) {
    $file = $_FILES['assignment_file'];

    if ($file['error'] === 0) {
        $file_ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $file_name = 'assignment_' . $assignment_id . '_student_' . $student_id . '.' . $file_ext;
        $upload_dir = 'submitted_assignments/';
        $file_path = $upload_dir . $file_name;

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            // Read student's submitted text
            $student_text = file_get_contents($file_path);

            // Fetch model answers from DB
            $answers_sql = "SELECT model_answer FROM assignment_questions WHERE assignment_id = $assignment_id";
            $answers_result = $connection->query($answers_sql);

            if (!$answers_result) {
                die("Query failed: " . $connection->error);
            }

            $total_score = 0;
            $question_count = 0;

            if ($answers_result && $answers_result->num_rows > 0) {
                while ($row = $answers_result->fetch_assoc()) {
                    $model = $row['model_answer'];
                    similar_text(strtolower($student_text), strtolower($model), $percent);
                    echo "Matching percentage: $percent<br>";  // Debugging line
                    $total_score += $percent;
                    $question_count++;
                }

                // Calculate total percentage score (average of all question scores)
                $percentage_score = $question_count > 0 ? round($total_score / $question_count, 2) : 0;
                echo "Total Score: $total_score, Question Count: $question_count<br>";  // Debugging line
                echo "Percentage Score: $percentage_score<br>";  // Debugging line

                // Scale the percentage score to a maximum of 150 marks
                $scaled_score = min(round(($percentage_score / 100) * 150, 2), 150);
                echo "Scaled Score: $scaled_score<br>";  // Debugging line

                $score_msg = "✅ Assignment submitted! You scored approximately <strong>$scaled_score</strong> out of 150.";
            } else {
                $score_msg = "⚠️ No model answers found for this assignment.";
                $scaled_score = 0;
            }

            // Insert submission (without score)
            $stmt = $connection->prepare("INSERT INTO submissions (student_id, assignment_id, submission_file, submitted_at) VALUES (?, ?, ?, NOW())");
            $stmt->bind_param("iss", $student_id, $assignment_id, $file_path);
            $stmt->execute();

            // Notify teacher
            $teacher_sql = "SELECT teacher_id FROM `add-courses` WHERE id = (SELECT course_id FROM assignments WHERE id = $assignment_id)";
            $teacher_result = $connection->query($teacher_sql);
            if ($teacher_result && $teacher_result->num_rows > 0) {
                $teacher = $teacher_result->fetch_assoc();
                $teacher_id = $teacher['teacher_id'];
                $message = "Student $student_id has submitted assignment $assignment_id.";
                $connection->query("INSERT INTO notifications (user_id, message) VALUES ($teacher_id, '$message')");
            }

            // Update the score in the submissions table
            $update_score_sql = "UPDATE submissions SET score = ? WHERE assignment_id = ? AND student_id = ?";
            $stmt = $connection->prepare($update_score_sql);
            $stmt->bind_param("dii", $scaled_score, $assignment_id, $student_id);
            $stmt->execute();

        } else {
            $score_msg = "❌ Error uploading the file.";
        }
    } else {
        $score_msg = "❌ No file uploaded or upload error.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>📤 Submit Assignment</title>
</head>
<body>

<h2>📤 Submit Assignment</h2>

<?php if (!empty($score_msg)): ?>
    <p><?= $score_msg ?></p>
<?php endif; ?>

<form action="" method="POST" enctype="multipart/form-data">
    <label for="assignment_file">Choose Assignment File (.txt):</label>
    <input type="file" name="assignment_file" id="assignment_file" accept=".txt" required>
    <button type="submit">Submit</button>
</form>

</body>
</html>
