<?php
session_start();

// Database connect
$conn = new mysqli("localhost", "root", "", "lms_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Success/Error message
$message = "";

// Dynamic student ID from session
if (isset($_SESSION['user_id'])) {
    $student_id = $_SESSION['user_id'];
} else {
    // Agar session nahi hai toh login page bhej do
    header("Location: /lms/login.php");
    exit();
}

// Jab enroll button dabaye
if (isset($_POST['enroll_course'])) {
    $course_id = intval($_POST['course_id']);
    
    // Fetch course name and level
    $course_query = $conn->query("SELECT course_name, level FROM `add-courses` WHERE id = $course_id");
    $course = $course_query->fetch_assoc();
    
    if ($course) {
        $level = $conn->real_escape_string($course['level']);
        
        // Check if already enrolled
        $check = $conn->query("SELECT * FROM course_enrollments WHERE student_id = $student_id AND course_id = $course_id");
        
        if ($check->num_rows > 0) {
            $message = "Already enrolled in this course!";
        } else {
            // Now insert with level
            $enroll = $conn->query("INSERT INTO course_enrollments (student_id, course_id, level) VALUES ($student_id, $course_id, '$level')");
            if ($enroll) {
                $message = "Successfully enrolled!";
            } else {
                $message = "Failed to enroll. Try again.";
            }
        }
    } else {
        $message = "Course not found!";
    }
}

// Jab unenroll button dabaye
if (isset($_POST['unenroll_course'])) {
    $course_id = intval($_POST['course_id']);

    $delete = $conn->query("DELETE FROM course_enrollments WHERE student_id = $student_id AND course_id = $course_id");
    
    if ($delete) {
        $message = "Successfully unenrolled!";
    } else {
        $message = "Failed to unenroll. Try again.";
    }
}

// Sare courses fetch
$courses = $conn->query("SELECT * FROM `add-courses`");

// Fetch enrolled courses for current student
$enrolled_courses = [];
$enrolled_result = $conn->query("SELECT course_id FROM course_enrollments WHERE student_id = $student_id");
while ($row = $enrolled_result->fetch_assoc()) {
    $enrolled_courses[] = $row['course_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Course Enrollment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            max-width: 800px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #f2f2f2;
        }
        button {
            background: #3498db;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #2980b9;
        }
        .btn-unenroll {
            background: #e74c3c;
        }
        .btn-unenroll:hover {
            background: #c0392b;
        }
        .message {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Enroll in a Course</h2>

    <?php if (!empty($message)): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Course Name</th>
                <th>Level</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $courses->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['course_name']) ?></td>
                    <td><?= htmlspecialchars($row['level']) ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="course_id" value="<?= $row['id'] ?>">
                            <?php if (in_array($row['id'], $enrolled_courses)): ?>
                                <button type="submit" name="unenroll_course" class="btn-unenroll" onclick="return confirm('Are you sure you want to unenroll?')">Unenroll</button>
                            <?php else: ?>
                                <button type="submit" name="enroll_course">Enroll</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
