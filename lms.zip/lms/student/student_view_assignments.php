<?php
session_start();
$connection = new mysqli("localhost", "root", "", "lms_db");

// Check DB connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check student_id from session
$student_id = $_SESSION['student_id'] ?? 2; // Default to 2 for testing

// SQL query to fetch assignments for the student
$sql = "SELECT 
            a.id AS assignment_id,
            a.title,
            a.deadline,
            a.total_marks,
            a.assignment_type, 
            ac.course_name,
            ac.level,
            s.id AS submission_id,
            s.submission_file
        FROM course_enrollments ce
        JOIN `add-courses` ac ON ce.course_id = ac.id  -- Backticks added here
        JOIN assignments a ON a.course_id = ac.id
        LEFT JOIN submissions s ON s.assignment_id = a.id AND s.student_id = ce.student_id
        WHERE ce.student_id = $student_id
        ORDER BY a.deadline DESC";

$result = $connection->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>📘 My Assignments</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f0f2f5; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 12px; border: 1px solid #ccc; text-align: left; }
        th { background: #f5f5f5; }
        .btn { padding: 5px 10px; border: none; cursor: pointer; text-decoration: none; display: inline-block; margin-top: 5px; }
        .view { background: #2196F3; color: white; }
        .submit { background: #4CAF50; color: white; }
        .download { background: #673AB7; color: white; }
        .check { background: #ff9800; color: white; }
    </style>
</head>
<body>

<h2>📘 My Assignments</h2>

<table>
    <thead>
        <tr>
            <th>Course</th>
            <th>Level</th>
            <th>Title</th>
            <th>Deadline</th>
            <th>Marks</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['course_name']) ?></td>
                <td><?= htmlspecialchars($row['level']) ?></td>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= htmlspecialchars($row['deadline']) ?></td>
                <td><?= htmlspecialchars($row['total_marks']) ?></td>
                <td>
                    <a href="/lms/student/view_assignment_pdf.php?id=<?= $row['assignment_id'] ?>" class="btn view" target="_blank">📄 View PDF</a>
                    
                    <?php if ($row['submission_id']): ?>
                        <a href="/lms/student/<?= htmlspecialchars($row['submission_file']) ?>" class="btn download" target="_blank">📥 Download Submitted</a>
                        
                        <?php if (strtolower($row['assignment_type']) === 'subjective'): ?>
                            <a href="\lms\student\submit.php?id=<?= $row['assignment_id'] ?>" class="btn check">✅ Check Answer</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="/lms/student/submit.php?id=<?= $row['assignment_id'] ?>" class="btn submit">📤 Submit</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="6">No assignments available.</td></tr>
    <?php endif; ?>
    </tbody>
</table>

</body>
</html>
