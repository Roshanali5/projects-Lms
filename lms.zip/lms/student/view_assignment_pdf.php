<?php
require __DIR__ . '/../vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

// Connect to database
$connection = new mysqli("localhost", "root", "", "lms_db");

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid request.");
}

$assignment_id = intval($_GET['id']);

// Fetch assignment
$assignmentQuery = "SELECT * FROM assignments WHERE id = $assignment_id";
$assignmentResult = $connection->query($assignmentQuery);
$assignment = $assignmentResult->fetch_assoc();

if (!$assignment) {
    die("Assignment not found.");
}

// Fetch questions
$questionsQuery = "SELECT question_text FROM assignment_questions WHERE assignment_id = $assignment_id";
$questionsResult = $connection->query($questionsQuery);

// Paths
$pdfFolder = __DIR__ . "/../assignments_pdfs/";
$pdfFilename = $assignment_id . ".pdf";
$pdfAbsolutePath = $pdfFolder . $pdfFilename;
$pdfRelativePath = "../assignments_pdfs/" . $pdfFilename;

// Generate PDF if not exists
if (!file_exists($pdfAbsolutePath)) {
    $options = new Options();
    $options->set('defaultFont', 'Arial');
    $dompdf = new Dompdf($options);

    $html = "<h2>{$assignment['title']}</h2>";
    $html .= "<p><strong>Deadline:</strong> {$assignment['deadline']}</p>";
    $html .= "<p><strong>Total Marks:</strong> {$assignment['total_marks']}</p>";
    $html .= "<h3>Questions:</h3>";

    if ($questionsResult->num_rows > 0) {
        while ($q = $questionsResult->fetch_assoc()) {
            $html .= "<p>• " . htmlspecialchars($q['question_text']) . "</p>";
        }
    } else {
        $html .= "<p>No questions available.</p>";
    }

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

   // Ensure the directory exists
if (!is_dir($pdfFolder)) {
    mkdir($pdfFolder, 0777, true); // recursively create folders if needed
}

// Save PDF to file
file_put_contents($pdfAbsolutePath, $dompdf->output());
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>📄 Assignment View</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f9f9f9; }
        h2 { color: #333; }
        .question { margin-bottom: 15px; padding: 10px; background: #fff; border-left: 4px solid #2196F3; }
        .download-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>

    <h2>📘 <?= htmlspecialchars($assignment['title']) ?></h2>
    <p><strong>Deadline:</strong> <?= htmlspecialchars($assignment['deadline']) ?></p>
    <p><strong>Total Marks:</strong> <?= htmlspecialchars($assignment['total_marks']) ?></p>
    <hr>

    <h3>📝 Questions:</h3>
    <?php
    $questionsResult->data_seek(0); // reset pointer after previous loop
    if ($questionsResult->num_rows > 0): ?>
        <?php while ($q = $questionsResult->fetch_assoc()): ?>
            <div class="question"><?= nl2br(htmlspecialchars($q['question_text'])) ?></div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No questions found for this assignment.</p>
    <?php endif; ?>

    <a href="<?= $pdfRelativePath ?>" class="download-btn" download>⬇️ Download PDF</a>



</body>
</html>
