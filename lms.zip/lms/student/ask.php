<?php
require 'C:\xampp\htdocs\lms\vendor\autoload.php';

use GuzzleHttp\Client;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['question'])) {
    $question = $_POST['question'];

    $client = new Client();
    try {
        $response = $client->post('https://openrouter.ai/api/v1/chat/completions', [
            'headers' => [
                'Authorization' => ' Bearer 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', // Replace with your API key
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'model' => 'openai/gpt-3.5-turbo', // or any model you have access to
                'messages' => [
                    ['role' => 'user', 'content' => $question]
                ],
            ],
        ]);

        $responseBody = $response->getBody();
        $body = json_decode($responseBody, true);
        $answer = $body['choices'][0]['message']['content'] ?? '❌ Unexpected response.';
    } catch (Exception $e) {
        $answer = "❌ Error: " . $e->getMessage();
    }

    echo json_encode(['answer' => $answer]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ask Anything & Share</title>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      background-color: #f0f4f8;
      color: #333;
    }

    header {
      background-color: #4CAF50;
      padding: 30px 20px;
      text-align: center;
      color: white;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
    }

    .container {
      max-width: 600px;
      margin: 30px auto;
      background: #ffffff;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    h1, h2 {
      margin-top: 0;
    }

    input[type="text"] {
      width: 100%;
      padding: 12px;
      margin: 15px 0;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }

    button {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 12px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 6px;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #45a049;
    }

    #responseBox {
      margin-top: 20px;
      background: #f1f1f1;
      padding: 15px;
      border-left: 5px solid #4CAF50;
      border-radius: 6px;
      text-align: left;
      white-space: pre-wrap;
    }

    .social-buttons {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      margin-top: 25px;
      gap: 10px;
    }

    .btn {
      padding: 10px 16px;
      color: white;
      border: none;
      border-radius: 6px;
      text-decoration: none;
      font-size: 14px;
      transition: opacity 0.3s ease;
    }

    .btn:hover {
      opacity: 0.85;
    }

    .btn-facebook {
      background-color: #3b5998;
    }

    .btn-twitter {
      background-color: #1da1f2;
    }

    @media (max-width: 600px) {
      .container {
        margin: 20px;
        padding: 20px;
      }

      button, .btn {
        width: 100%;
        text-align: center;
      }
    }
  </style>
</head>
<body>

<header>
  <h1>📘 Share Your Accomplishments & ChatGPT</h1>
</header>

<div class="container">
  <h2>Ask Me Anything ChatGPT</h2>
  <form method="POST" id="askForm">
    <input type="text" name="question" placeholder="Type your question..." required>
    <button type="submit">Ask</button>
  </form>
  <div id="responseBox"></div>

  <h2>Share Your Accomplishment</h2>
  <p>Post about your progress and invite others to help or join you!</p>
  <div class="social-buttons">
    <a href="https://www.facebook.com/sharer/sharer.php?u=http://yourpage.com" target="_blank" class="btn btn-facebook">Share on Facebook</a>
    <a href="https://twitter.com/intent/tweet?text=I%20just%20completed%20an%20assignment!&url=http://yourpage.com" target="_blank" class="btn btn-twitter">Share on Twitter</a>
  </div>
</div>

<script>
  document.getElementById('askForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);

    const response = await fetch('', {
      method: 'POST',
      body: formData
    });

    const result = await response.json();
    document.getElementById('responseBox').innerText = result.answer;
  });
</script>

</body>
</html>
