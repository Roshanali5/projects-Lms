<?php
include 'config.php';

// ✅ Connection check kar lo
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $second_name = mysqli_real_escape_string($conn, $_POST['second_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // ✅ Check if passwords match
    if ($password !== $confirm_password) {
        die("<script>alert('Password and Confirm Password do not match.'); window.history.back();</script>");
    }

    // ✅ Password hashing
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // ✅ Check if username already exists
    $check_user = "SELECT * FROM register WHERE second_name = '$second_name'";
    $result = mysqli_query($conn, $check_user);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Username already exists. Please choose another.'); window.history.back();</script>";
    } else {
        // ✅ Insert query
        $insert_user = "INSERT INTO register (first_name, second_name, email, phone_number, password, gender, role, status) 
                        VALUES ('$first_name', '$second_name', '$email', '$phone_number', '$hashed_password', '$gender', '$role', 'PENDING')";

        // ✅ Debugging (Query check)
        if (!mysqli_query($conn, $insert_user)) {
            die("Query Error: " . mysqli_error($conn)); // Show SQL error
        }

        // ✅ Success message
        echo "<script>alert('Registration Successful. Wait for admin approval.'); window.location.href='login.php';</script>";
    }

    mysqli_close($conn);
}