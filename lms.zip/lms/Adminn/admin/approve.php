<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];

    $sql = "UPDATE register SET status = 'APPROVED' WHERE id = '$user_id'";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('User approved successfully!'); window.location.href = 'pending_users.php';</script>";
    } else {
        echo "❌ Error: " . mysqli_error($conn);
    }
}
?>
