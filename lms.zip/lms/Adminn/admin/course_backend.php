<?php
$conn = new mysqli("localhost", "root", "", "lms_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add new course
if (isset($_POST['add_course'])) {
    $name = $conn->real_escape_string($_POST['course_name']);
    $level = $conn->real_escape_string($_POST['level']);

    $conn->query("INSERT INTO `add-courses` (`course_name`, `level`) VALUES ('$name', '$level')");
    header("Location: \lms\teacher\course_view.php");
    exit();
}

// Delete course
if (isset($_POST['delete_id'])) {
    $id = intval($_POST['delete_id']);
    $conn->query("DELETE FROM `add-courses` WHERE id = $id");
    header("Location: \lms\teacher\course_view.php");
    exit();
}
?>
