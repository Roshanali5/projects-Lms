<?php
include 'config.php';

$sql = "SELECT * FROM register WHERE status = 'PENDING'";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("❌ Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Approve Users</title>
    <style>
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .approve-btn {
            background: green;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

<h2 style="text-align:center;">Pending Users</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>password</th>
        <th>Role</th>
        <th>Action</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['first_name'] . " " . $row['second_name']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['phone_number']; ?></td>
        <td><?php echo $row['password']; ?></td>
        <td><?php echo $row['role']; ?></td>
        <td>
            <form method="post" action="approve.php">
                <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                <button type="submit" class="approve-btn">Approve</button>
            </form>
        </td>
    </tr>
    <?php } ?>

</table>

</body>
</html>
