<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'C:\xampp\htdocs\lms\Adminn\admin\config.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query from correct table 'register'
    $stmt = $conn->prepare("SELECT * FROM register WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            // Redirect based on role
            switch ($user['role']) {
                case 'student':
                    header("Location: /lms/student/student.php");
                    break;
                case 'instructor':
                    header("Location: /lms/teacher/teacher.php");
                    break;
                case 'admin':
                    header("Location: \lms\Adminn\admin.php");
                    break;
                default:
                    header("Location: /lms/login.php");
            }
            exit();
        } else {
            echo "Incorrect password!";
        }
    } else {
        echo "User not found!";
    }
}
?>
